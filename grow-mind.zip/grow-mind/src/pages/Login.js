// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import '../';

// const Login = () => {
//   const [email, setEmail] = useState('');
//   const [error, setError] = useState('');
//   const navigate = useNavigate();

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (/^[a-zA-Z0-9._%+-]+@amdocs.com$/.test(email)) {
//       setError('');
//       navigate('/home');
//     } else {
//       setError('Please enter a valid amdocs.com email');
//     }
//   };

//   return (
//     <div>
//       <h1>Login</h1>
//       <form onSubmit={handleSubmit}>
//         <input
//           type="email"
//           value={email}
//           onChange={(e) => setEmail(e.target.value)}
//           placeholder="Enter your amdocs email"
//         />
//         <button type="submit">Submit</button>
//       </form>
//       {error && <p style={{ color: 'red' }}>{error}</p>}
//     </div>
//   );
// };

// export default Login;

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';

const Login = () => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (/^[a-zA-Z0-9._%+-]+@amdocs.com$/.test(email)) {
      setError('');
      navigate('/home');
    } else {
      setError('Please enter a valid amdocs.com email');
    }
  };

  return (
    <div>
      <h1>Login</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your amdocs email"
        />
        <button type="submit">Submit</button>
      </form>
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
};

export default Login;
