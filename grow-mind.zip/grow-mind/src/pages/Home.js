// import React from 'react';
// import { Link } from 'react-router-dom';
// import '../App.css';

// const Home = () => {
//   const games = ['Game 1', 'Game 2', 'Game 3'];

//   return (
//     <div>
//       <h1>Home</h1>
//       <ul>
//         {games.map((game, index) => (
//           <li key={index}>
//             <img src={`/path/to/your/game-image-${index + 1}.jpg`} alt={`Game ${index + 1}`} style={{ width: '100%', borderRadius: '10px' }} />
//             <h2>{game}</h2>
//             <button><Link to={`/game/${index + 1}`}>Start Game</Link></button>
//             <button>About/Rules</button>
//           </li>
//         ))}
//         <li>
//           <h2>Crossword Puzzle</h2>
//           <button><Link to="/crossword">Start Crossword</Link></button>
//         </li>
//       </ul>
//     </div>
//   );
// };

// export default Home;



import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import '../App.css';

const Home = () => {
  const [games, setGames] = useState([]);

  useEffect(() => {
    // Fetch games data from an API or backend
    const fetchGames = async () => {
      const response = await fetch('/api/games');
      const data = await response.json();
      setGames(data);
    };
    fetchGames();
  }, []);

  return (
    <div>
      <h1>Home</h1>
      <ul>
        {games.map((game, index) => (
          <li key={index}>
            <img src={game.image} alt={game.name} style={{ width: '100%', borderRadius: '10px' }} />
            <h2>{game.name}</h2>
            <button><Link to={`/game/${game.id}`}>Start Game</Link></button>
            <button>About/Rules</button>
          </li>
        ))}
        <li>
          <h2>Crossword Puzzle</h2>
          <button><Link to="/crossword">Start Crossword</Link></button>
        </li>
      </ul>
    </div>
  );
};

export default Home;
