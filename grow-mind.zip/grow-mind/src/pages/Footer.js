import React from 'react';
import '../App.css';

const Footer = () => {
    return (
      <footer className="footer">
        <p>Crafted by Hansika & Shubham</p>
      </footer>
    );
  };

export default Footer;


{/* <span role="img" aria-label="fun">🎉</span> & <span role="img" aria-label="love">❤️</span>  */}