// import React from 'react';
// import '../App.css';

// const LeaderBoard = () => {
//   const leaders = [
//     { name: 'Player 1', score: 100 },
//     { name: 'Player 2', score: 90 },
//     { name: 'Player 3', score: 80 },
//   ];

//   return (
//     <div>
//       <h1>LeaderBoard</h1>
//       <ol>
//         {leaders.map((leader, index) => (
//           <li key={index}>
//             <h2>{leader.name} - {leader.score}</h2>
//           </li>
//         ))}
//       </ol>
//     </div>
//   );
// };

// export default LeaderBoard;


import React, { useState, useEffect } from 'react';
import '../App.css';

const LeaderBoard = () => {
  const [leaders, setLeaders] = useState([]);

  useEffect(() => {
    fetch('/api/leaderboard')
      .then(response => response.json())
      .then(data => setLeaders(data))
      .catch(error => console.error('Error fetching leaderboard data:', error));
  }, []);

  return (
    <div>
      <h1>LeaderBoard</h1>
      <ol>
        {leaders.map((leader, index) => (
          <li key={index}>
            <h2>{leader.name} - {leader.score}</h2>
          </li>
        ))}
      </ol>
    </div>
  );
};

export default LeaderBoard;
