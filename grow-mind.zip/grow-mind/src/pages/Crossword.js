import React, { useState } from 'react';
import '../styling/Crossword.css'; // Importing the CSS file from the styling folder

const crosswordData = [
  { number: 1, answer: "SERIAL", question: "SIM Information", direction: "across", row: 0, col: 0 },
  { number: 4, answer: "PREPAID", question: "Active / Pending / consumed Pass Information", direction: "across", row: 3, col: 0 },
  { number: 5, answer: "RATED", question: "Features associated with a PP/SOC", direction: "across", row: 4, col: 0 },
  { number: 6, answer: "ACCOUNT", question: "Account Type and Account Sub Type rules / parameters / boundaries", direction: "across", row: 5, col: 0 },
  { number: 7, answer: "TOGGLE", question: "CR ON / OFF Flags", direction: "across", row: 6, col: 3 },
  { number: 8, answer: "SUBSCRIBER", question: "Subscriber Information", direction: "across", row: 7, col: 4 },
  { number: 10, answer: "ONLINE", question: "Has all the error_codes and their description", direction: "across", row: 9, col: 2 },
  { number: 1, answer: "SOC", question: "SOC and AT/ST mapping", direction: "down", row: 0, col: 0 },
  { number: 2, answer: "PROFILE", question: "Security parameters of a Profile", direction: "down", row: 0, col: 3 },
  { number: 3, answer: "JOBDBCONNECT", question: "Has Job connect details", direction: "down", row: 0, col: 5 },
  { number: 6, answer: "ADDRESS", question: "Address Details", direction: "down", row: 5, col: 0 },
  { number: 8, answer: "CLASSIFI", question: "Soc Classification Relation", direction: "down", row: 7, col: 4 },
  { number: 9, answer: "CYCLE", question: "Cycle Information", direction: "down", row: 7, col: 7 }
];

const Crossword = () => {
  const [userAnswers, setUserAnswers] = useState({});
  const [highlightedClue, setHighlightedClue] = useState(null);
  const [score, setScore] = useState(null);
  const [answerStatus, setAnswerStatus] = useState({});

  const handleInputChange = (row, col, event) => {
    const value = event.target.value.toUpperCase();
    setUserAnswers({ ...userAnswers, [`${row}-${col}`]: value });
  };

  const handleClueClick = (clue) => {
    setHighlightedClue(clue);
  };

  const handleSubmit = () => {
    let score = 0;
    const status = {};
    crosswordData.forEach((clue) => {
      let correct = true;
      for (let i = 0; i < clue.answer.length; i++) {
        const key = clue.direction === 'across' ? `${clue.row}-${clue.col + i}` : `${clue.row + i}-${clue.col}`;
        if (userAnswers[key] !== clue.answer[i]) {
          correct = false;
          status[key] = 'incorrect';
        } else {
          status[key] = 'correct';
        }
      }
      if (correct) {
        score += 10;
      }
    });
    setScore(score);
    setAnswerStatus(status);
  };

  const renderGrid = () => {
    const grid = [];
    for (let i = 0; i < 10; i++) {
      const row = [];
      for (let j = 0; j < 10; j++) {
        const cellNumber = getCellNumber(i, j);
        const isHighlighted = isCellHighlighted(i, j);
        const status = answerStatus[`${i}-${j}`];
        const isEmptyCell = !crosswordData.some(clue => {
          const key = clue.direction === 'across' ? `${clue.row}-${clue.col + i}` : `${clue.row + i}-${clue.col}`;
          return key === `${i}-${j}`;
        });
        row.push(
          <div key={`${i}-${j}`} className={`crossword-cell ${isEmptyCell ? 'empty-cell' : ''} ${isHighlighted ? 'highlighted' : ''} ${status}`}>
            {cellNumber && <div className="cell-number">{cellNumber}</div>}
            {!isEmptyCell && (
              <input
                value={userAnswers[`${i}-${j}`] || ''}
                onChange={(e) => handleInputChange(i, j, e)}
                maxLength="1"
                disabled={score !== null} // Disable input after submission
              />
            )}
          </div>
        );
      }
      grid.push(<div key={i} className="crossword-row">{row}</div>);
    }
    return grid;
  };

  const getCellNumber = (row, col) => {
    const cell = crosswordData.find(
      (entry) => entry.row === row && entry.col === col
    );
    return cell ? cell.number : '';
  };

  const isCellHighlighted = (row, col) => {
    if (!highlightedClue) return false;
    for (let i = 0; i < highlightedClue.answer.length; i++) {
      const key = highlightedClue.direction === 'across' ? `${highlightedClue.row}-${highlightedClue.col + i}` : `${highlightedClue.row + i}-${highlightedClue.col}`;
      if (key === `${row}-${col}`) return true;
    }
    return false;
  };

  const renderClues = (direction) => {
    const clues = crosswordData.filter(clue => clue.direction === direction);
    return (
      <div className="clues-section">
        <h3>{direction.charAt(0).toUpperCase() + direction.slice(1)}</h3>
        <ul>
          {clues.map((clue, index) => (
            <li key={index} onClick={() => handleClueClick(clue)}>
              {clue.number}. {clue.question}
            </li>
          ))}
        </ul>
      </div>
    );
  };

  return (
    <div className="crossword-container">
      <div className="crossword-grid">{renderGrid()}</div>
      <div className="clues">
        {renderClues("across")}
        {renderClues("down")}
        <button className="submit-button" onClick={handleSubmit}>Submit</button>
        {score !== null && (
          <div className="score">
            <h3>Your Score: {score}</h3>
            <h3>Correct Answers:</h3>
            <ul>
              {crosswordData.map((clue, index) => (
                <li key={index}>
                  {clue.number}. {clue.answer} ({clue.direction})
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};

export default Crossword;
