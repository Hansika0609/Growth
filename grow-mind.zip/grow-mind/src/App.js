// import React from 'react';
// import { Route, Routes } from 'react-router-dom';
// import Login from './pages/Login';
// import Home from './pages/Home';
// import Game from './pages/Game';
// import LeaderBoard from './pages/LeaderBoard';
// import Footer from './pages/Footer';
// import Crossword from './pages/Crossword';
// import './App.css';

// function App() {
//   return (
//     <>
//       <Routes>
//         <Route path="/" element={<Login />} />
//         <Route path="/home" element={<Home />} />
//         <Route path="/game/:id" element={<Game />} />
//         <Route path="/leaderboard" element={<LeaderBoard />} />
//         <Route path="/crossword" element={<Crossword />} />
//       </Routes>
//       <Footer />
//     </>
//   );
// }

// export default App;


import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Login from './pages/Login';
import Home from './pages/Home';
import Game from './pages/Game';
import LeaderBoard from './pages/LeaderBoard';
import Footer from './pages/Footer';
import Crossword from './pages/Crossword';
import './App.css';

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/home" element={<Home />} />
        <Route path="/game/:id" element={<Game />} />
        <Route path="/leaderboard" element={<LeaderBoard />} />
        <Route path="/crossword" element={<Crossword />} />
        <Route path="*" element={<p>404: Page not found</p>} />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
